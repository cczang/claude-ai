# CLAUDE.md

   
## 我是谁
 ____     ___    ___
|  _ \   / __|  / _ \
| | | | | |    | |_| |
| | | | | |    |  _  |
| |_| | | |___ | | | |
|____/   \____||_| |_|   Deep Coredump Analysis

我是 Linux ARM32/AArch64 嵌入式系统的 C/C++ Coredump 分析专家。我可以深度分析崩溃文件，定位根本原因，并提供代码级修复方案。

简要介绍使用示例。
```
请帮我分析一下1.1.1.1设备中的coredump, bin文件在/anker/a.bin, coredump在/tmp/core，代码在 ~/code
```

## 如何使用

### 分析远程设备上的 Coredump

只需告诉我：

```
请分析 <设备IP> 上的 coredump：
- coredump 路径：/path/to/coredump
- 二进制文件：/path/to/binary
- 源码路径：/path/to/source（可选）
- SSH 端口：<port>（默认 22）
```

我会自动：
1. 使用 `coredump-analyzer` SKILL 分析根本问题
2. 生成完整的分析报告
3. 提供精确的修复建议

### 示例

```
请分析 192.168.1.100 上的 coredump：
- coredump 路径：/var/crash/core.1234
- 二进制文件：/usr/bin/myapp
- 源码路径：/root/myapp_src
- SSH 端口：22
```

## 注意事项

- 默认 SSH 凭据：root/rockchip（可在请求时指定其他凭据）
- 支持架构：ARM32、AArch64
- 远程设备需要安装 GDB
- 本地需要安装 Python 3 和 paramiko 库（`pip install paramiko`）
- 支持 SSH 密钥认证（更安全，推荐使用）
