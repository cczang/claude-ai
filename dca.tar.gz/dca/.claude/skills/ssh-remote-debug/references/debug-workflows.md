# Common Remote Debug Workflows

This document provides common workflows for remote debugging and coredump analysis.

## Coredump Analysis Workflow

### 1. Locate and Download Coredump

```bash
# Find coredump files
ssh_executor.py <host> "find /var/crash -name 'core.*' -o -name '*.core'"

# Download coredump
scp_transfer.py download <host>:/var/crash/core.12345 ./coredump/
```

### 2. Download Required Libraries and Executable

```bash
# Get crashed executable path from coredump info
ssh_executor.py <host> "file /var/crash/core.12345"

# Download executable
scp_transfer.py download <host>:/path/to/executable ./

# Download shared libraries
scp_transfer.py download -r <host>:/lib ./debug-libs/
scp_transfer.py download -r <host>:/usr/lib ./debug-libs/
```

### 3. Remote GDB Analysis

```bash
# Install gdb if not present
ssh_executor.py <host> "apt-get update && apt-get install -y gdb"

# Get backtrace
ssh_executor.py <host> "gdb -batch -ex 'bt' /path/to/exe /path/to/core"

# Get detailed info
ssh_executor.py <host> "gdb -batch -ex 'thread apply all bt' -ex 'info registers' /path/to/exe /path/to/core"
```

## System Debugging Workflow

### Check System Status

```bash
# Check system resources
ssh_executor.py <host> "top -bn1 | head -20"
ssh_executor.py <host> "free -h"
ssh_executor.py <host> "df -h"

# Check running processes
ssh_executor.py <host> "ps aux | grep <process_name>"

# Check system logs
ssh_executor.py <host> "dmesg | tail -100"
ssh_executor.py <host> "journalctl -xe --no-pager | tail -100"
```

### Memory Leak Investigation

```bash
# Monitor memory usage
ssh_executor.py <host> "cat /proc/<pid>/status | grep -E 'VmSize|VmRSS|VmData'"

# Check memory maps
ssh_executor.py <host> "cat /proc/<pid>/maps"

# Use valgrind if available
ssh_executor.py <host> "valgrind --leak-check=full /path/to/program"
```

## Batch Command Examples

Create a file `debug-commands.txt`:
```
uname -a
free -h
df -h
ps aux | head -20
dmesg | tail -50
```

Execute batch:
```bash
ssh_executor.py <host> --batch debug-commands.txt
```

## Remote Debugging Session

### Setup Remote GDB Server

```bash
# Install gdbserver on remote
ssh_executor.py <host> "apt-get install -y gdbserver"

# Start gdbserver
ssh_executor.py <host> "gdbserver :2345 /path/to/program &"
```

### Connect from Local GDB

```bash
# On local machine
gdb /path/to/local/executable
(gdb) target remote <host>:2345
(gdb) continue
```

## File Operations for Debug

### Upload Debug Symbols

```bash
# Upload debug symbols
scp_transfer.py upload -r ./debug-symbols <host>:/usr/lib/debug/
```

### Download Logs for Analysis

```bash
# Download all logs
ssh_executor.py <host> "tar czf /tmp/logs.tar.gz /var/log"
scp_transfer.py download <host>:/tmp/logs.tar.gz ./logs.tar.gz
```

### Clean Up Remote Files

```bash
# Remove old coredumps
ssh_executor.py <host> "find /var/crash -name 'core.*' -mtime +7 -delete"

# Clean temp files
ssh_executor.py <host> "rm -rf /tmp/debug-*"
```

## Performance Analysis

### CPU Profiling

```bash
# Check CPU usage
ssh_executor.py <host> "mpstat 1 10"

# Profile with perf
ssh_executor.py <host> "perf record -g -p <pid> -- sleep 10"
ssh_executor.py <host> "perf report > /tmp/perf-report.txt"
scp_transfer.py download <host>:/tmp/perf-report.txt ./
```

### Network Debugging

```bash
# Check network connections
ssh_executor.py <host> "netstat -tulpn"
ssh_executor.py <host> "ss -tunap"

# Capture packets
ssh_executor.py <host> "tcpdump -i eth0 -w /tmp/capture.pcap -c 1000"
scp_transfer.py download <host>:/tmp/capture.pcap ./
```

## Tips

1. **Use JSON output** for parsing: `ssh_executor.py <host> "command" --json`
2. **Stop on error** in batch mode: `--stop-on-error`
3. **Verbose mode** for troubleshooting: `-v`
4. **Timeout considerations**: Commands timeout after 5 minutes, transfers after 10 minutes
5. **Config file usage**: Store frequently-used servers in config file for convenience
