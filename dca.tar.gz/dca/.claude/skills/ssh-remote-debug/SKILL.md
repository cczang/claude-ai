---
name: ssh-remote-debug
description: Remote debugging and coredump analysis via SSH. Execute commands on remote servers, transfer files, and perform system debugging. Use when the user needs to (1) execute commands on remote Linux devices, (2) analyze coredump files remotely, (3) debug programs with GDB on remote servers, (4) transfer files to/from remote servers, (5) check system status or logs remotely, or (6) perform remote troubleshooting tasks. Default credentials are root/rockchip if not specified.
---

# SSH Remote Debug

## Overview

Execute commands and analyze coredumps on remote servers via SSH using paramiko (pure Python, no external tools required). Supports single/batch command execution, file transfers, SSH key authentication, and debugging workflows with default credentials (root/rockchip).

## Quick Start

### Execute Single Command

```bash
python scripts/ssh_executor.py <host> "command"

# Examples
python scripts/ssh_executor.py 192.168.1.100 "uname -a"
python scripts/ssh_executor.py 192.168.1.100 "ps aux | grep myapp"
```

Default credentials: `root/rockchip`

### Execute with Custom Credentials

```bash
python scripts/ssh_executor.py <host> "command" -u <username> -p <password>

# Example
python scripts/ssh_executor.py 192.168.1.100 "ls -la" -u admin -p mypassword
```

### Execute with SSH Key

```bash
python scripts/ssh_executor.py <host> "command" -k <path_to_private_key>

# Example
python scripts/ssh_executor.py 192.168.1.100 "ls -la" -k ~/.ssh/id_rsa
```

### Transfer Files

```bash
# Upload file
python scripts/scp_transfer.py upload <local_file> <remote_path> -H <host>

# Download file
python scripts/scp_transfer.py download <remote_path> <local_file> -H <host>

# Examples
python scripts/scp_transfer.py upload debug.log /tmp/ -H 192.168.1.100
python scripts/scp_transfer.py download /var/crash/core.1234 ./coredump/ -H 192.168.1.100

# Upload using SSH key
python scripts/scp_transfer.py upload file.txt /tmp/ -H 192.168.1.100 -k ~/.ssh/id_rsa
```

## Common Tasks

### Remote Debugging

**Find and download coredump:**
```bash
# Locate coredumps
python scripts/ssh_executor.py <host> "find /var/crash -name 'core.*'"

# Download coredump
python scripts/scp_transfer.py download /var/crash/core.1234 ./core.1234 -H <host>
```

**Analyze with GDB remotely:**
```bash
# Get backtrace
python scripts/ssh_executor.py <host> "gdb -batch -ex 'bt' /path/to/exe /path/to/core"

# Detailed analysis
python scripts/ssh_executor.py <host> "gdb -batch -ex 'thread apply all bt' -ex 'info registers' /path/to/exe /path/to/core"
```

### System Monitoring

**Check system status:**
```bash
# Resource usage
python scripts/ssh_executor.py <host> "free -h && df -h"

# Process info
python scripts/ssh_executor.py <host> "ps aux | grep <process>"

# System logs
python scripts/ssh_executor.py <host> "dmesg | tail -50"
```

### Batch Commands

Create a file with commands (one per line):
```
# commands.txt
uname -a
free -h
df -h
ps aux | head -20
```

Execute batch:
```bash
python scripts/ssh_executor.py <host> --batch commands.txt
```

Stop on first error:
```bash
python scripts/ssh_executor.py <host> --batch commands.txt --stop-on-error
```

### Directory Transfer

```bash
# Upload directory
python scripts/scp_transfer.py upload -r /local/dir /remote/dir -H <host>

# Download directory
python scripts/scp_transfer.py download -r /remote/dir /local/dir -H <host>
```

## Configuration File

Save frequently-used servers in a config file for convenience.

**Create config file** (see `assets/config-template.json`):
```json
{
  "servers": {
    "dev-board": {
      "host": "192.168.1.100",
      "username": "root",
      "password": "rockchip",
      "port": 22
    }
  }
}
```

**Use config:**
```bash
# Execute command
python scripts/ssh_executor.py --config servers.json --server dev-board "command"

# Transfer file
python scripts/scp_transfer.py --config servers.json --server dev-board upload file.txt /tmp/
```

## Advanced Features

### JSON Output

For parsing command results programmatically:
```bash
python scripts/ssh_executor.py <host> "command" --json
```

Output format:
```json
{
  "command": "command",
  "exit_code": 0,
  "stdout": "...",
  "stderr": "..."
}
```

### Verbose Mode

For troubleshooting connection issues:
```bash
python scripts/ssh_executor.py <host> "command" -v
python scripts/scp_transfer.py upload file.txt <host>:/tmp/ -v
```

### Custom Port

```bash
python scripts/ssh_executor.py <host> "command" -P 2222
python scripts/scp_transfer.py upload file.txt <host>:/tmp/ -P 2222
```

## Common Workflows

See [references/debug-workflows.md](references/debug-workflows.md) for detailed workflows including:
- Coredump analysis procedures
- System debugging steps
- Memory leak investigation
- Performance profiling
- Remote GDB setup
- Log collection and analysis

## Prerequisites

The scripts require Python 3 and the `paramiko` library:

```bash
# Install paramiko
pip install paramiko

# Or using pip3
pip3 install paramiko
```

Paramiko is a pure Python SSH implementation, so no external tools like sshpass are needed.

## Script Reference

### ssh_executor.py

Execute commands on remote servers.

**Usage:**
```bash
python scripts/ssh_executor.py [options] <host> <command>
```

**Key options:**
- `-u, --username`: SSH username (default: root)
- `-p, --password`: SSH password (default: rockchip)
- `-P, --port`: SSH port (default: 22)
- `-k, --key-file`: Path to SSH private key file (optional)
- `-b, --batch`: Execute commands from file
- `--stop-on-error`: Stop batch on first error
- `--json`: JSON output format
- `-v, --verbose`: Verbose output
- `--config`: Config file path
- `--server`: Server name from config

**Authentication:** Supports both password and SSH key authentication. When using password authentication, the script will also try ssh-agent and default key locations automatically.

**Timeouts:** Commands timeout after 5 minutes.

### scp_transfer.py

Transfer files to/from remote servers via SFTP.

**Usage:**
```bash
python scripts/scp_transfer.py [options] <action> <source> <destination>
```

**Actions:**
- `upload`: Upload to remote
- `download`: Download from remote
- `batch`: Batch transfers from JSON file

**Key options:**
- `-H, --host`: Remote host (required)
- `-u, --username`: SSH username (default: root)
- `-p, --password`: SSH password (default: rockchip)
- `-P, --port`: SSH port (default: 22)
- `-k, --key-file`: Path to SSH private key file (optional)
- `-r, --recursive`: Transfer directories
- `--json`: JSON output
- `-v, --verbose`: Verbose output
- `--config`: Config file path
- `--server`: Server name from config

**Authentication:** Supports both password and SSH key authentication. When using password authentication, the script will also try ssh-agent and default key locations automatically.

**Timeouts:** No timeout for transfers (handled by paramiko internally).

## Tips

1. **Default credentials**: Scripts default to root/rockchip if not specified
2. **SSH keys**: For better security, use SSH key authentication with `-k` option
3. **Config files**: Save time by storing frequently-used servers (including key_file) in config
4. **Batch operations**: Use batch mode for multiple commands or transfers
5. **JSON output**: Use `--json` for parsing results in scripts
6. **Verbose mode**: Use `-v` for troubleshooting SSH connection issues
7. **Error handling**: Use `--stop-on-error` in batch mode to halt on failures
8. **No external tools**: Uses pure Python (paramiko), works on any platform without system dependencies
