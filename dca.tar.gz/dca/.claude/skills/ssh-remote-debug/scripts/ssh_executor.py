#!/usr/bin/env python3
"""
SSH Remote Command Executor
Execute commands on remote servers via SSH with default credentials support.
Uses paramiko for SSH connectivity (no external tools required).
"""

import argparse
import sys
import json
from pathlib import Path
import socket
import warnings

# Suppress paramiko warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)

try:
    import paramiko
except ImportError:
    print("Error: paramiko not found. Please install: pip install paramiko", file=sys.stderr)
    sys.exit(1)


def load_server_config(config_path):
    """Load server configuration from JSON file."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError as e:
        print(f"Error parsing config file: {e}", file=sys.stderr)
        return {}


def create_ssh_client(host, username='root', password='rockchip', port=22,
                     key_file=None, timeout=10, verbose=False):
    """
    Create and return an SSH client connection.

    Args:
        host: Remote host address
        username: SSH username (default: root)
        password: SSH password (default: rockchip)
        port: SSH port (default: 22)
        key_file: Path to SSH private key file (optional)
        timeout: Connection timeout in seconds
        verbose: Print verbose output

    Returns:
        paramiko.SSHClient: Connected SSH client or None on failure
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        if verbose:
            print(f"Connecting to {username}@{host}:{port}", file=sys.stderr)

        # Try key-based authentication first if key_file is provided
        if key_file and Path(key_file).exists():
            if verbose:
                print(f"Using SSH key: {key_file}", file=sys.stderr)
            client.connect(
                hostname=host,
                port=port,
                username=username,
                key_filename=key_file,
                timeout=timeout,
                look_for_keys=False,
                allow_agent=False
            )
        else:
            # Fall back to password authentication
            if verbose:
                print("Using password authentication", file=sys.stderr)
            client.connect(
                hostname=host,
                port=port,
                username=username,
                password=password,
                timeout=timeout,
                look_for_keys=True,  # Try ssh-agent and default keys first
                allow_agent=True
            )

        if verbose:
            print("Connection established successfully", file=sys.stderr)

        return client

    except paramiko.AuthenticationException:
        print(f"Authentication failed for {username}@{host}", file=sys.stderr)
        return None
    except socket.timeout:
        print(f"Connection timeout: Could not connect to {host}:{port}", file=sys.stderr)
        return None
    except socket.gaierror:
        print(f"Could not resolve hostname: {host}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Connection error: {str(e)}", file=sys.stderr)
        return None


def execute_ssh_command(host, command, username='root', password='rockchip',
                       port=22, key_file=None, timeout=300, verbose=False):
    """
    Execute a single command on remote server via SSH.

    Args:
        host: Remote host address
        command: Command to execute
        username: SSH username (default: root)
        password: SSH password (default: rockchip)
        port: SSH port (default: 22)
        key_file: Path to SSH private key file (optional)
        timeout: Command execution timeout in seconds (default: 300)
        verbose: Print verbose output

    Returns:
        tuple: (exit_code, stdout, stderr)
    """
    # Always source /etc/profile to ensure environment variables are properly set
    # This is crucial for tools like gdb that depend on LD_LIBRARY_PATH and other env vars
    if not command.strip().startswith('source'):
        command = f"source /etc/profile 2>/dev/null; {command}"

    if verbose:
        print(f"Executing: {command}", file=sys.stderr)

    client = create_ssh_client(host, username, password, port, key_file, 10, verbose)
    if not client:
        return 1, "", "Failed to establish SSH connection"

    try:
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)

        # Read output
        stdout_data = stdout.read().decode('utf-8', errors='replace')
        stderr_data = stderr.read().decode('utf-8', errors='replace')
        exit_code = stdout.channel.recv_exit_status()

        if verbose:
            print(f"Exit code: {exit_code}", file=sys.stderr)

        return exit_code, stdout_data, stderr_data

    except socket.timeout:
        return 124, "", f"Command timed out after {timeout} seconds"
    except Exception as e:
        return 1, "", f"Error executing command: {str(e)}"
    finally:
        client.close()


def execute_batch_commands(host, commands, username='root', password='rockchip',
                          port=22, key_file=None, verbose=False, stop_on_error=False):
    """
    Execute multiple commands sequentially on remote server.
    Uses a single SSH connection for efficiency.

    Args:
        host: Remote host address
        commands: List of commands to execute
        username: SSH username (default: root)
        password: SSH password (default: rockchip)
        port: SSH port (default: 22)
        key_file: Path to SSH private key file (optional)
        verbose: Print verbose output
        stop_on_error: Stop execution if any command fails

    Returns:
        list: List of command result dictionaries
    """
    results = []

    # Create a single connection for all commands
    client = create_ssh_client(host, username, password, port, key_file, 10, verbose)
    if not client:
        return [{"command": cmd, "exit_code": 1, "stdout": "",
                "stderr": "Failed to establish SSH connection"} for cmd in commands]

    try:
        for i, cmd in enumerate(commands, 1):
            if verbose:
                print(f"\n[{i}/{len(commands)}] Executing: {cmd}", file=sys.stderr)

            # Source profile for each command
            full_cmd = f"source /etc/profile 2>/dev/null; {cmd}"

            try:
                stdin, stdout, stderr = client.exec_command(full_cmd, timeout=300)

                stdout_data = stdout.read().decode('utf-8', errors='replace')
                stderr_data = stderr.read().decode('utf-8', errors='replace')
                exit_code = stdout.channel.recv_exit_status()

                results.append({
                    'command': cmd,
                    'exit_code': exit_code,
                    'stdout': stdout_data,
                    'stderr': stderr_data
                })

                if stop_on_error and exit_code != 0:
                    if verbose:
                        print(f"Command failed with exit code {exit_code}. Stopping.",
                              file=sys.stderr)
                    break

            except Exception as e:
                results.append({
                    'command': cmd,
                    'exit_code': 1,
                    'stdout': '',
                    'stderr': f"Error executing command: {str(e)}"
                })
                if stop_on_error:
                    break

    finally:
        client.close()

    return results


def main():
    parser = argparse.ArgumentParser(
        description='Execute commands on remote servers via SSH',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Execute single command with defaults (root/rockchip)
  %(prog)s 192.168.1.100 "uname -a"

  # Execute with custom credentials
  %(prog)s 192.168.1.100 "ls -la" -u admin -p mypassword

  # Execute using SSH key
  %(prog)s 192.168.1.100 "ls -la" -k ~/.ssh/id_rsa

  # Execute multiple commands from file
  %(prog)s 192.168.1.100 --batch commands.txt

  # Use server from config file
  %(prog)s --config servers.json --server dev-server "df -h"

  # Execute with JSON output format
  %(prog)s 192.168.1.100 "ps aux" --json
        '''
    )

    parser.add_argument('host', nargs='?', help='Remote host address')
    parser.add_argument('command', nargs='?', help='Command to execute')
    parser.add_argument('-u', '--username', default='root', help='SSH username (default: root)')
    parser.add_argument('-p', '--password', default='rockchip', help='SSH password (default: rockchip)')
    parser.add_argument('-P', '--port', type=int, default=22, help='SSH port (default: 22)')
    parser.add_argument('-k', '--key-file', help='Path to SSH private key file')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    parser.add_argument('-b', '--batch', help='Execute commands from file (one per line)')
    parser.add_argument('--stop-on-error', action='store_true',
                       help='Stop batch execution on first error')
    parser.add_argument('--config', help='Path to server configuration file')
    parser.add_argument('--server', help='Server name from config file')
    parser.add_argument('--json', action='store_true', help='Output results in JSON format')

    args = parser.parse_args()

    # Load server config if specified
    server_config = {}
    if args.config:
        config = load_server_config(args.config)
        if args.server and args.server in config.get('servers', {}):
            server_config = config['servers'][args.server]
            if not args.host:
                args.host = server_config.get('host')
            if 'username' in server_config and args.username == 'root':
                args.username = server_config.get('username')
            if 'password' in server_config and args.password == 'rockchip':
                args.password = server_config.get('password')
            if 'port' in server_config and args.port == 22:
                args.port = server_config.get('port')
            if 'key_file' in server_config and not args.key_file:
                args.key_file = server_config.get('key_file')

    # Validate required arguments
    if not args.host:
        parser.error("host is required")

    if not args.command and not args.batch:
        parser.error("either command or --batch is required")

    # Execute commands
    if args.batch:
        # Read commands from file
        try:
            with open(args.batch, 'r') as f:
                commands = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        except FileNotFoundError:
            print(f"Error: Batch file '{args.batch}' not found", file=sys.stderr)
            return 1

        results = execute_batch_commands(
            args.host, commands, args.username, args.password,
            args.port, args.key_file, args.verbose, args.stop_on_error
        )

        if args.json:
            print(json.dumps(results, indent=2))
        else:
            # Print results
            for i, result in enumerate(results, 1):
                print(f"\n{'='*60}")
                print(f"Command {i}: {result['command']}")
                print(f"Exit Code: {result['exit_code']}")
                print(f"{'='*60}")
                if result['stdout']:
                    print("STDOUT:")
                    print(result['stdout'])
                if result['stderr']:
                    print("STDERR:")
                    print(result['stderr'], file=sys.stderr)

        # Return non-zero if any command failed
        failed = [r for r in results if r['exit_code'] != 0]
        return 1 if failed else 0

    else:
        # Execute single command
        exit_code, stdout, stderr = execute_ssh_command(
            args.host, args.command, args.username, args.password,
            args.port, args.key_file, 300, args.verbose
        )

        if args.json:
            result = {
                'command': args.command,
                'exit_code': exit_code,
                'stdout': stdout,
                'stderr': stderr
            }
            print(json.dumps(result, indent=2))
        else:
            if stdout:
                print(stdout, end='')
            if stderr:
                print(stderr, end='', file=sys.stderr)

        return exit_code


if __name__ == '__main__':
    sys.exit(main())
