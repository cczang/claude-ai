#!/usr/bin/env python3
"""
SCP/SFTP File Transfer Utility
Transfer files to/from remote servers with default credentials support.
Uses paramiko for SFTP connectivity (no external tools required).
"""

import argparse
import sys
import json
from pathlib import Path
import socket
import warnings
import os
import stat

# Suppress paramiko warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)

try:
    import paramiko
except ImportError:
    print("Error: paramiko not found. Please install: pip install paramiko", file=sys.stderr)
    sys.exit(1)


def load_server_config(config_path):
    """Load server configuration from JSON file."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError as e:
        print(f"Error parsing config file: {e}", file=sys.stderr)
        return {}


def create_ssh_client(host, username='root', password='rockchip', port=22,
                     key_file=None, timeout=10, verbose=False):
    """
    Create and return an SSH client connection.

    Args:
        host: Remote host address
        username: SSH username (default: root)
        password: SSH password (default: rockchip)
        port: SSH port (default: 22)
        key_file: Path to SSH private key file (optional)
        timeout: Connection timeout in seconds
        verbose: Print verbose output

    Returns:
        paramiko.SSHClient: Connected SSH client or None on failure
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        if verbose:
            print(f"Connecting to {username}@{host}:{port}", file=sys.stderr)

        # Try key-based authentication first if key_file is provided
        if key_file and Path(key_file).exists():
            if verbose:
                print(f"Using SSH key: {key_file}", file=sys.stderr)
            client.connect(
                hostname=host,
                port=port,
                username=username,
                key_filename=key_file,
                timeout=timeout,
                look_for_keys=False,
                allow_agent=False
            )
        else:
            # Fall back to password authentication
            if verbose:
                print("Using password authentication", file=sys.stderr)
            client.connect(
                hostname=host,
                port=port,
                username=username,
                password=password,
                timeout=timeout,
                look_for_keys=True,
                allow_agent=True
            )

        if verbose:
            print("Connection established successfully", file=sys.stderr)

        return client

    except paramiko.AuthenticationException:
        print(f"Authentication failed for {username}@{host}", file=sys.stderr)
        return None
    except socket.timeout:
        print(f"Connection timeout: Could not connect to {host}:{port}", file=sys.stderr)
        return None
    except socket.gaierror:
        print(f"Could not resolve hostname: {host}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"Connection error: {str(e)}", file=sys.stderr)
        return None


def upload_file_sftp(sftp, local_path, remote_path, verbose=False):
    """
    Upload a file or directory using SFTP.

    Args:
        sftp: SFTP client
        local_path: Local file/directory path
        remote_path: Remote file/directory path
        verbose: Print verbose output

    Returns:
        bool: True if successful, False otherwise
    """
    local_path = Path(local_path)

    if local_path.is_file():
        # Upload single file
        if verbose:
            print(f"Uploading file: {local_path} -> {remote_path}", file=sys.stderr)
        try:
            sftp.put(str(local_path), remote_path)
            return True
        except Exception as e:
            print(f"Error uploading file: {e}", file=sys.stderr)
            return False

    elif local_path.is_dir():
        # Upload directory recursively
        if verbose:
            print(f"Uploading directory: {local_path} -> {remote_path}", file=sys.stderr)

        # Create remote directory
        try:
            sftp.mkdir(remote_path)
        except IOError:
            # Directory may already exist
            pass

        # Upload all files in directory
        for item in local_path.rglob('*'):
            if item.is_file():
                relative_path = item.relative_to(local_path)
                remote_item_path = f"{remote_path}/{relative_path}".replace('\\', '/')

                # Create parent directories on remote
                remote_parent = '/'.join(remote_item_path.split('/')[:-1])
                try:
                    sftp.mkdir(remote_parent)
                except IOError:
                    pass

                if verbose:
                    print(f"  {item} -> {remote_item_path}", file=sys.stderr)

                try:
                    sftp.put(str(item), remote_item_path)
                except Exception as e:
                    print(f"Error uploading {item}: {e}", file=sys.stderr)
                    return False

        return True

    else:
        print(f"Error: {local_path} does not exist", file=sys.stderr)
        return False


def download_file_sftp(sftp, remote_path, local_path, verbose=False):
    """
    Download a file or directory using SFTP.

    Args:
        sftp: SFTP client
        remote_path: Remote file/directory path
        local_path: Local file/directory path
        verbose: Print verbose output

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        file_attr = sftp.stat(remote_path)
    except IOError as e:
        print(f"Error: Remote path does not exist: {remote_path}", file=sys.stderr)
        return False

    # Check if remote path is a file or directory
    if stat.S_ISDIR(file_attr.st_mode):
        # Download directory recursively
        if verbose:
            print(f"Downloading directory: {remote_path} -> {local_path}", file=sys.stderr)

        local_path = Path(local_path)
        local_path.mkdir(parents=True, exist_ok=True)

        # List all items in remote directory
        def download_dir_recursive(sftp, remote_dir, local_dir):
            try:
                items = sftp.listdir_attr(remote_dir)
            except IOError as e:
                print(f"Error listing directory {remote_dir}: {e}", file=sys.stderr)
                return False

            for item in items:
                remote_item = f"{remote_dir}/{item.filename}"
                local_item = local_dir / item.filename

                if stat.S_ISDIR(item.st_mode):
                    # Create local directory and recurse
                    local_item.mkdir(exist_ok=True)
                    if not download_dir_recursive(sftp, remote_item, local_item):
                        return False
                else:
                    # Download file
                    if verbose:
                        print(f"  {remote_item} -> {local_item}", file=sys.stderr)
                    try:
                        sftp.get(remote_item, str(local_item))
                    except Exception as e:
                        print(f"Error downloading {remote_item}: {e}", file=sys.stderr)
                        return False

            return True

        return download_dir_recursive(sftp, remote_path, local_path)

    else:
        # Download single file
        if verbose:
            print(f"Downloading file: {remote_path} -> {local_path}", file=sys.stderr)

        # Create parent directory if needed
        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            sftp.get(remote_path, str(local_path))
            return True
        except Exception as e:
            print(f"Error downloading file: {e}", file=sys.stderr)
            return False


def transfer_file(host, source, destination, direction, username='root',
                 password='rockchip', port=22, key_file=None, recursive=False,
                 verbose=False):
    """
    Transfer file(s) using SFTP.

    Args:
        host: Remote host address
        source: Source path
        destination: Destination path
        direction: 'upload' or 'download'
        username: SSH username (default: root)
        password: SSH password (default: rockchip)
        port: SSH port (default: 22)
        key_file: Path to SSH private key file (optional)
        recursive: Transfer directories recursively
        verbose: Print verbose output

    Returns:
        tuple: (exit_code, stdout, stderr)
    """
    if verbose:
        print(f"Transferring: {source} -> {destination}", file=sys.stderr)

    client = create_ssh_client(host, username, password, port, key_file, 10, verbose)
    if not client:
        return 1, "", "Failed to establish SSH connection"

    try:
        sftp = client.open_sftp()

        if direction == 'upload':
            success = upload_file_sftp(sftp, source, destination, verbose)
        else:  # download
            success = download_file_sftp(sftp, source, destination, verbose)

        sftp.close()

        if success:
            return 0, "", ""
        else:
            return 1, "", "Transfer failed"

    except Exception as e:
        return 1, "", f"Error during file transfer: {str(e)}"
    finally:
        client.close()


def upload_file(local_path, remote_host, remote_path, username='root',
               password='rockchip', port=22, key_file=None, recursive=False,
               verbose=False):
    """Upload file(s) to remote server."""
    return transfer_file(remote_host, local_path, remote_path, 'upload',
                        username, password, port, key_file, recursive, verbose)


def download_file(remote_host, remote_path, local_path, username='root',
                 password='rockchip', port=22, key_file=None, recursive=False,
                 verbose=False):
    """Download file(s) from remote server."""
    return transfer_file(remote_host, remote_path, local_path, 'download',
                        username, password, port, key_file, recursive, verbose)


def batch_transfer(host, transfers, username='root', password='rockchip',
                  port=22, key_file=None, recursive=False, verbose=False,
                  stop_on_error=False):
    """
    Execute multiple file transfers.

    Args:
        host: Remote host address
        transfers: List of (source, destination, direction) tuples
                  direction can be 'upload' or 'download'
        username: SSH username
        password: SSH password
        port: SSH port
        key_file: Path to SSH private key file (optional)
        recursive: Transfer directories recursively
        verbose: Print verbose output
        stop_on_error: Stop on first error

    Returns:
        list: List of transfer results
    """
    results = []

    for i, (source, dest, direction) in enumerate(transfers, 1):
        if verbose:
            print(f"\n[{i}/{len(transfers)}] {direction.upper()}: {source} -> {dest}",
                  file=sys.stderr)

        exit_code, stdout, stderr = transfer_file(
            host, source, dest, direction, username, password,
            port, key_file, recursive, verbose
        )

        results.append({
            'source': source,
            'destination': dest,
            'direction': direction,
            'exit_code': exit_code,
            'stdout': stdout,
            'stderr': stderr
        })

        if stop_on_error and exit_code != 0:
            if verbose:
                print(f"Transfer failed with exit code {exit_code}. Stopping.",
                      file=sys.stderr)
            break

    return results


def main():
    parser = argparse.ArgumentParser(
        description='Transfer files to/from remote servers via SFTP',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Upload file to remote server
  %(prog)s upload local.txt /tmp/remote.txt -H 192.168.1.100

  # Download file from remote server
  %(prog)s download /tmp/remote.txt local.txt -H 192.168.1.100

  # Upload directory recursively
  %(prog)s upload -r /local/dir /remote/dir -H 192.168.1.100

  # Upload with custom credentials
  %(prog)s upload file.txt /tmp/ -H 192.168.1.100 -u admin -p mypass

  # Upload using SSH key
  %(prog)s upload file.txt /tmp/ -H 192.168.1.100 -k ~/.ssh/id_rsa

  # Use server from config file
  %(prog)s --config servers.json --server dev upload file.txt /tmp/

  # Batch transfers from JSON file
  %(prog)s batch --file transfers.json -H 192.168.1.100
        '''
    )

    parser.add_argument('action', choices=['upload', 'download', 'batch'],
                       help='Transfer action')
    parser.add_argument('source', nargs='?', help='Source path')
    parser.add_argument('destination', nargs='?', help='Destination path')
    parser.add_argument('-H', '--host', help='Remote host address')
    parser.add_argument('-u', '--username', default='root',
                       help='SSH username (default: root)')
    parser.add_argument('-p', '--password', default='rockchip',
                       help='SSH password (default: rockchip)')
    parser.add_argument('-P', '--port', type=int, default=22,
                       help='SSH port (default: 22)')
    parser.add_argument('-k', '--key-file', help='Path to SSH private key file')
    parser.add_argument('-r', '--recursive', action='store_true',
                       help='Transfer directories recursively')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Verbose output')
    parser.add_argument('--config', help='Path to server configuration file')
    parser.add_argument('--server', help='Server name from config file')
    parser.add_argument('--file', help='Batch transfer file (JSON format)')
    parser.add_argument('--stop-on-error', action='store_true',
                       help='Stop batch transfer on first error')
    parser.add_argument('--json', action='store_true',
                       help='Output results in JSON format')

    args = parser.parse_args()

    # Load server config if specified
    if args.config:
        config = load_server_config(args.config)
        if args.server and args.server in config.get('servers', {}):
            server_config = config['servers'][args.server]
            if not args.host:
                args.host = server_config.get('host')
            if 'username' in server_config and args.username == 'root':
                args.username = server_config.get('username')
            if 'password' in server_config and args.password == 'rockchip':
                args.password = server_config.get('password')
            if 'port' in server_config and args.port == 22:
                args.port = server_config.get('port')
            if 'key_file' in server_config and not args.key_file:
                args.key_file = server_config.get('key_file')

    if not args.host:
        parser.error("host is required (use -H or --host)")

    if args.action == 'batch':
        # Batch transfer mode
        if not args.file:
            parser.error("--file is required for batch mode")

        try:
            with open(args.file, 'r') as f:
                batch_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Error reading batch file: {e}", file=sys.stderr)
            return 1

        transfers = []
        for item in batch_data.get('transfers', []):
            src = item['source']
            dst = item['destination']
            direction = item.get('direction', 'upload')
            transfers.append((src, dst, direction))

        results = batch_transfer(
            args.host, transfers, args.username, args.password,
            args.port, args.key_file, args.recursive, args.verbose,
            args.stop_on_error
        )

        if args.json:
            print(json.dumps(results, indent=2))
        else:
            for i, result in enumerate(results, 1):
                print(f"\n{'='*60}")
                print(f"Transfer {i}: {result['source']} -> {result['destination']}")
                print(f"Direction: {result['direction']}")
                print(f"Exit Code: {result['exit_code']}")
                print(f"{'='*60}")
                if result['stderr']:
                    print(result['stderr'], file=sys.stderr)

        failed = [r for r in results if r['exit_code'] != 0]
        return 1 if failed else 0

    else:
        # Single transfer mode
        if not args.source or not args.destination:
            parser.error("source and destination are required")

        exit_code, stdout, stderr = transfer_file(
            args.host, args.source, args.destination, args.action,
            args.username, args.password, args.port, args.key_file,
            args.recursive, args.verbose
        )

        if args.json:
            result = {
                'source': args.source,
                'destination': args.destination,
                'action': args.action,
                'exit_code': exit_code,
                'stdout': stdout,
                'stderr': stderr
            }
            print(json.dumps(result, indent=2))
        else:
            if exit_code == 0:
                print(f"Transfer successful: {args.source} -> {args.destination}")
            else:
                print(f"Transfer failed with exit code {exit_code}", file=sys.stderr)
                if stderr:
                    print(stderr, file=sys.stderr)

        return exit_code


if __name__ == '__main__':
    sys.exit(main())
