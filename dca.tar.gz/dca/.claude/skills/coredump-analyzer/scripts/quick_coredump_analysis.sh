#!/bin/bash
# Quick Coredump Analysis Tool for Embedded Devices
# 嵌入式设备快速 Coredump 分析工具
#
# 此脚本可在资源受限的嵌入式设备上运行
# 不需要 Python，仅使用 bash + GDB
#
# 用法:
#   ./quick_coredump_analysis.sh <binary> <coredump> [output_file]

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

usage() {
    cat << EOF
用法: $0 <binary> <coredump> [output_file]

快速分析 coredump 文件并生成报告

参数:
    binary      - 崩溃的可执行文件路径
    coredump    - coredump 文件路径
    output_file - 输出报告文件（可选，默认输出到终端）

示例:
    $0 /usr/bin/myapp /var/coredump/core.1234
    $0 /usr/bin/myapp /var/coredump/core.1234 crash_report.txt

环境要求:
    - GDB (必需)
    - bash (必需)
    - 不需要 Python

EOF
    exit 1
}

# 检查参数
if [ $# -lt 2 ]; then
    echo -e "${RED}错误: 缺少必需参数${NC}"
    usage
fi

BINARY="$1"
COREDUMP="$2"
OUTPUT="${3:-}"

# 检查文件是否存在
if [ ! -f "$BINARY" ]; then
    echo -e "${RED}错误: 二进制文件不存在: $BINARY${NC}"
    exit 1
fi

if [ ! -f "$COREDUMP" ]; then
    echo -e "${RED}错误: Coredump 文件不存在: $COREDUMP${NC}"
    exit 1
fi

# 检查 GDB 是否可用
if ! command -v gdb &> /dev/null; then
    echo -e "${RED}错误: 未找到 GDB${NC}"
    exit 1
fi

# 先获取实际的栈帧数量（获取最后一个帧的编号+1）
echo -e "${BLUE}正在统计栈帧数量...${NC}"
LAST_FRAME=$(gdb "$BINARY" "$COREDUMP" -batch -ex "bt" 2>&1 | grep "^#" | tail -1 | awk '{print $1}' | tr -d '#')
FRAME_COUNT=$((LAST_FRAME + 1))
echo -e "${GREEN}发现 $FRAME_COUNT 个栈帧 (最后帧编号: #$LAST_FRAME)${NC}"
echo ""

# 创建临时 GDB 命令文件
TMPFILE=$(mktemp)
trap "rm -f $TMPFILE" EXIT

# 先写入 GDB 脚本（使用引号保护变量）
cat > "$TMPFILE" << 'GDBEOF'
# 禁用分页
set pagination off
set print pretty on
set print array on

# 定义栈帧分析函数
define analyze_stack_consumption
  echo =========================================================================\n
  echo Frame#  SP Address          Size(bytes)  Size(KB)  Function/Location\n
  echo =========================================================================\n

  set $frame_idx = 0
  set $next_sp = 0
  set $first_sp = 0
  set $last_sp = 0
  set $found_frames = 0

  # 先获取第一帧的信息
  select-frame 0
  set $curr_sp = (unsigned long)$sp
  set $first_sp = $curr_sp

  # 遍历所有帧，计算每一帧的栈消耗
  set $frame_idx = 0
  while $frame_idx < FRAME_COUNT_PLACEHOLDER
    select-frame $frame_idx
    set $curr_sp = (unsigned long)$sp

    # 尝试获取下一帧的 SP 来计算当前帧的栈消耗
    set $next_frame_idx = $frame_idx + 1
    set $size = 0
    set $has_next = 0

    if $next_frame_idx < FRAME_COUNT_PLACEHOLDER
      select-frame $next_frame_idx
      set $next_sp = (unsigned long)$sp
      set $has_next = 1

      # 计算当前帧的栈消耗 = 下一帧SP - 当前帧SP (栈向下增长，调用者SP更大)
      set $size = $next_sp - $curr_sp
      if $size < 0
        set $size = 0 - $size
      end
    end

    # 输出当前帧的信息
    if $has_next == 0
      # 最后一帧，没有下一帧来计算消耗
      printf "#%-5d  0x%016lx  %-12s  %-7s\n", $frame_idx, $curr_sp, "N/A", "N/A"
      set $found_frames = $found_frames + 1
    else
      # 有下一帧，可以计算栈消耗
      if $size < 10485760
        set $size_kb = $size / 1024
        printf "#%-5d  0x%016lx  %-12ld  %-7ld\n", $frame_idx, $curr_sp, $size, $size_kb
        set $found_frames = $found_frames + 1
      else
        printf "#%-5d  0x%016lx  (异常 - 栈消耗过大: %ld bytes)\n", $frame_idx, $curr_sp, $size
      end
    end

    set $last_sp = $curr_sp
    set $frame_idx = $frame_idx + 1
  end

  # 计算总栈使用
  echo =========================================================================\n
  set $total = $first_sp - $last_sp
  if $total < 0
    set $total = 0 - $total
  end
  set $total_kb = $total / 1024
  printf "总帧数: %d 帧\n", $found_frames
  printf "总栈使用: %ld bytes (%ld KB)\n", $total, $total_kb

  # 查找最大栈消耗的帧
  echo \n
  echo [说明]\n
  echo - 栈向下增长, Size = 下一帧SP(调用者) - 当前帧SP\n
  echo - 显示的栈消耗是该帧自己使用的栈空间\n
  echo - 最后一帧无法计算消耗（因为没有下一帧参考）\n
  echo - 关注栈消耗较大的函数（通常 >1KB 需要注意）\n
end

echo ========================================================================\n
echo 快速 Coredump 分析报告\n
echo ========================================================================\n
echo \n

# 基本信息
echo [1] 基本信息\n
echo ------------------------------------------------------------------------\n
info program
echo \n

# 信号信息
echo [2] 信号信息\n
echo ------------------------------------------------------------------------\n
info signals SIGSEGV
info signals SIGABRT
info signals SIGBUS
echo \n

# 线程信息
echo [3] 线程信息\n
echo ------------------------------------------------------------------------\n
info threads
echo \n

# 当前线程堆栈
echo [4] 崩溃线程堆栈 (详细)\n
echo ------------------------------------------------------------------------\n
bt
echo \n
bt full
echo \n

# 栈帧消耗分析
echo [4.1] 逐层栈帧消耗\n
echo ------------------------------------------------------------------------\n
analyze_stack_consumption
echo \n

# 寄存器状态
echo [5] 寄存器状态\n
echo ------------------------------------------------------------------------\n
info registers
echo \n

# 崩溃位置代码
echo [6] 崩溃位置反汇编\n
echo ------------------------------------------------------------------------\n
x/20i $pc-40
echo \n

# 栈内存
echo [7] 栈内存 (前128字节)\n
echo ------------------------------------------------------------------------\n
x/128bx $sp
echo \n

# 检查 LR 寄存器 (ARM/AArch64)
echo [8] Link Register 检查 (ARM/AArch64)\n
echo ------------------------------------------------------------------------\n
# 尝试查看 LR 指向的指令（可能失败）
# x/i $lr-4
# x/i $x30-4
echo 提示: 手动执行 'x/i $lr-4' 或 'x/i $x30-4'\n
echo \n

# 当前栈帧
echo [9] 当前栈帧详情\n
echo ------------------------------------------------------------------------\n
info frame
info locals
info args
echo \n

# 内存映射
echo [10] 内存映射\n
echo ------------------------------------------------------------------------\n
info proc mappings
echo \n

# 共享库
echo [11] 共享库\n
echo ------------------------------------------------------------------------\n
info sharedlibrary
echo \n

# 所有线程堆栈（简略）
echo [12] 所有线程堆栈\n
echo ------------------------------------------------------------------------\n
thread apply all bt
echo \n

echo ========================================================================\n
echo 分析完成\n
echo ========================================================================\n
echo \n
echo [后续步骤]\n
echo 1. 检查堆栈回溯确定崩溃位置\n
echo 2. 检查寄存器查找可疑值\n
echo 3. 检查崩溃点周围的内存\n
echo 4. 如需深度分析，使用 GDB 交互模式和专用脚本\n
echo \n

quit
GDBEOF

# 替换占位符为实际的帧数
sed -i "s/FRAME_COUNT_PLACEHOLDER/$FRAME_COUNT/g" "$TMPFILE"

# 显示进度
echo -e "${GREEN}开始分析 coredump...${NC}"
echo -e "${BLUE}二进制: ${BINARY}${NC}"
echo -e "${BLUE}Coredump: ${COREDUMP}${NC}"
echo ""

# 执行 GDB 分析
if [ -n "$OUTPUT" ]; then
    echo -e "${YELLOW}输出到文件: ${OUTPUT}${NC}"
    gdb "$BINARY" "$COREDUMP" -batch -x "$TMPFILE" > "$OUTPUT" 2>&1
    echo -e "${GREEN}分析完成！报告已保存到: ${OUTPUT}${NC}"
    echo ""
    echo -e "${YELLOW}查看报告:${NC}"
    echo "  cat $OUTPUT"
    echo "  less $OUTPUT"
else
    # 输出到终端
    gdb "$BINARY" "$COREDUMP" -batch -x "$TMPFILE" 2>&1 | tee
fi

echo ""
echo -e "${GREEN}提示: 如需交互式调试，运行:${NC}"
echo "  gdb $BINARY $COREDUMP"
echo ""
echo -e "${YELLOW}加载分析脚本:${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "  (gdb) source $SCRIPT_DIR/memory_fingerprint.gdb"
echo "  (gdb) source $SCRIPT_DIR/stack_recovery.gdb"
echo "  (gdb) source $SCRIPT_DIR/vptr_checker.gdb"
echo "  (gdb) source $SCRIPT_DIR/gdb_batch_commands.txt"
