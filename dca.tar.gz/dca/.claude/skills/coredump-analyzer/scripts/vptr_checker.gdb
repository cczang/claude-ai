# Virtual Table Pointer Checker - Pure GDB Commands
# 虚表指针检查器 - 纯 GDB 命令
#
# 用法：
#   (gdb) source vptr_checker.gdb
#   (gdb) check-vptr <object_address>
#
# 说明：
#   检查 C++ 对象的虚表指针 (vptr) 是否有效
#   vptr 是对象的前 8 字节（64位）或前 4 字节（32位）

define check-vptr
    if $argc < 1
        printf "用法: check-vptr <object_address>\n"
        printf "示例: check-vptr 0x7fffffffd000\n"
        printf "      check-vptr $rdi  # x86-64 的 this\n"
        printf "      check-vptr $x0   # AArch64 的 this\n"
    else
        set $obj = $arg0

        printf "======================================================================\n"
        printf "虚表指针 (vptr) 检查器\n"
        printf "======================================================================\n"
        printf "对象地址: 0x%lx\n\n", $obj

        # 检测指针大小
        if sizeof(void*) == 8
            set $ptr_size = 8
            set $vptr = *(unsigned long*)$obj
            printf "架构: 64-bit\n"
        else
            set $ptr_size = 4
            set $vptr = *(unsigned int*)$obj
            printf "架构: 32-bit\n"
        end

        printf "VPtr 值: 0x%lx\n\n", $vptr

        printf "[验证检查]\n"
        printf "----------------------------------------------------------------------\n"

        # 检查 1: vptr 是否为空
        if $vptr == 0
            printf "✗ 失败: vptr 为 NULL\n"
            printf "  原因: 对象未初始化或已被清零\n"
        else
            printf "✓ 通过: vptr 非空\n"
        end

        # 检查 2: vptr 是否看起来像有效地址
        set $looks_valid = 0
        if $vptr > 0x400000 && $vptr < 0x800000
            printf "✓ 通过: vptr 指向主程序段范围\n"
            set $looks_valid = 1
        end
        if $vptr > 0x7f0000000000 && $vptr < 0x7fffffffffff
            printf "✓ 通过: vptr 指向共享库范围\n"
            set $looks_valid = 1
        end
        if !$looks_valid
            printf "✗ 警告: vptr 地址看起来异常 (0x%lx)\n", $vptr
            printf "  可能被损坏或指向意外位置\n"
        end

        # 检查 3: 尝试查找符号
        printf "\n符号信息:\n"
        info symbol $vptr

        # 检查 4: 查看虚表内容（前几个函数指针）
        printf "\n[虚表内容]\n"
        printf "----------------------------------------------------------------------\n"
        printf "虚表条目（函数指针）:\n"

        if $ptr_size == 8
            printf "[0] 0x%016lx\n", *(unsigned long*)($vptr + 0)
            printf "[1] 0x%016lx\n", *(unsigned long*)($vptr + 8)
            printf "[2] 0x%016lx\n", *(unsigned long*)($vptr + 16)
            printf "[3] 0x%016lx\n", *(unsigned long*)($vptr + 24)
            printf "[4] 0x%016lx\n", *(unsigned long*)($vptr + 32)
        else
            printf "[0] 0x%08x\n", *(unsigned int*)($vptr + 0)
            printf "[1] 0x%08x\n", *(unsigned int*)($vptr + 4)
            printf "[2] 0x%08x\n", *(unsigned int*)($vptr + 8)
            printf "[3] 0x%08x\n", *(unsigned int*)($vptr + 12)
            printf "[4] 0x%08x\n", *(unsigned int*)($vptr + 16)
        end

        printf "\n尝试反汇编第一个虚函数:\n"
        if $ptr_size == 8
            set $first_func = *(unsigned long*)$vptr
        else
            set $first_func = *(unsigned int*)$vptr
        end
        x/3i $first_func

        printf "\n[对象内存布局]\n"
        printf "----------------------------------------------------------------------\n"
        printf "对象前 64 字节（包括 vptr）:\n"
        x/64bx $obj

        printf "\n======================================================================\n"
        printf "[总结]\n"

        if $looks_valid && $vptr != 0
            printf "✓ vptr 看起来有效 - 指向预期的虚表位置\n"
        else
            printf "✗ vptr 看起来已损坏\n\n"
            printf "[调试提示]\n"
            printf "  1. 检查对象附近成员的缓冲区溢出\n"
            printf "  2. 检查写入此对象的操作\n"
            printf "  3. 验证对象构造/析构未失败\n"
            printf "  4. 检查 use-after-free（对象已删除但指针仍在使用）\n"
            printf "  5. 查找类型混淆（错误的转换）\n"
        end
        printf "======================================================================\n"
    end
end

document check-vptr
检查 C++ 对象虚表指针的有效性

用法: check-vptr <object_address>

参数:
    object_address - C++ 对象的地址（表达式）

示例:
    check-vptr 0x7fffffffd000
    check-vptr $rdi      # x86-64 的 'this' 指针
    check-vptr $x0       # AArch64 的 'this' 指针
    check-vptr myobject

说明:
    检查 C++ 对象的第一个指针（vptr）是否指向有效的虚表。
    vptr 损坏通常是由缓冲区溢出、use-after-free 或类型混淆引起的。

输出:
    - vptr 值和位置
    - 有效性检查结果
    - 虚表内容
    - 调试建议
end

printf "已加载 check-vptr 命令\n"
printf "使用方法: check-vptr <object_address>\n"
