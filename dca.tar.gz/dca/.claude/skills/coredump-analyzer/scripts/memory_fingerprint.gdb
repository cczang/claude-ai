# Memory Fingerprint Analysis - Pure GDB Commands
# 内存指纹分析 - 纯 GDB 命令
#
# 用法：
#   (gdb) source memory_fingerprint.gdb
#   (gdb) memory-fingerprint <address> [size]
#
# 说明：
#   分析指定地址的内存模式，识别：
#   - ASCII 字符串痕迹（缓冲区溢出证据）
#   - 重复字节模式（memset 伪影）
#   - 魔术数字（毒药值、初始化标记）

define memory-fingerprint
    if $argc < 1
        printf "用法: memory-fingerprint <address> [size]\n"
        printf "示例: memory-fingerprint 0x7fffffffd000\n"
        printf "      memory-fingerprint $sp 256\n"
    else
        set $addr = $arg0
        set $size = 256

        if $argc >= 2
            set $size = $arg1
        end

        printf "======================================================================\n"
        printf "内存指纹分析: 0x%lx (%d 字节)\n", $addr, $size
        printf "======================================================================\n\n"

        printf "[1] 十六进制视图 (前64字节):\n"
        printf "----------------------------------------------------------------------\n"
        x/64bx $addr
        printf "\n"

        printf "[2] ASCII 字符串检测:\n"
        printf "----------------------------------------------------------------------\n"
        # 尝试将内存作为字符串打印
        x/s $addr
        x/s $addr+16
        x/s $addr+32
        x/s $addr+48
        printf "\n"

        printf "[3] 指针视图 (查找代码/数据指针):\n"
        printf "----------------------------------------------------------------------\n"
        # AArch64 使用 8 字节指针
        x/8gx $addr
        printf "\n"

        printf "[4] 常见模式检测提示:\n"
        printf "----------------------------------------------------------------------\n"
        printf "  - 如果看到可读的 ASCII 字符串 -> 可能是缓冲区溢出\n"
        printf "  - 如果看到重复的字节 (0x00, 0xff, 0xcc, 0xdd) -> memset 操作\n"
        printf "  - 如果看到 0xdeadbeef, 0xbaadf00d -> 魔术数字/毒药值\n"
        printf "  - 如果看到指向代码段的指针 -> 可能是返回地址或函数指针\n"
        printf "\n"

        printf "手动检查命令:\n"
        printf "  x/Ns  <addr>  - 查看字符串 (N=字符数)\n"
        printf "  x/Nx  <addr>  - 查看十六进制 (N=字数)\n"
        printf "  x/Nwx <addr>  - 查看字 (4字节)\n"
        printf "  x/Ngx <addr>  - 查看巨字 (8字节)\n"
        printf "======================================================================\n"
    end
end

document memory-fingerprint
分析内存模式以识别损坏指纹

用法: memory-fingerprint <address> [size]

参数:
    address - 要分析的内存地址（可以是表达式如 $sp）
    size    - 要分析的字节数（默认 256）

示例:
    memory-fingerprint 0x7fffffffd000
    memory-fingerprint $sp 512
    memory-fingerprint malloc_chunk_addr

输出:
    - 十六进制内存转储
    - ASCII 字符串检测
    - 指针视图
    - 常见模式检测提示
end

printf "已加载 memory-fingerprint 命令\n"
printf "使用方法: memory-fingerprint <address> [size]\n"
