# GDB script for stack recovery when the call stack is completely corrupted
# Supports both 32-bit (ARM32) and 64-bit (AArch64/x86-64) architectures
#
# Usage: stack-recovery <start_address> <scan_slots> <text_section_start> <text_section_end>
#
# This script scans a memory region and attempts to recover stack frames by:
# 1. Auto-detecting architecture (32-bit or 64-bit)
# 2. Looking for valid code addresses within the text section range
# 3. Resolving symbols for those addresses
# 4. Displaying source line information
#
# Parameters:
#   start_address      - Starting address to scan (typically $sp or stack pointer)
#   scan_slots         - Number of pointer-sized slots to scan
#                        - 32-bit: each slot = 4 bytes
#                        - 64-bit: each slot = 8 bytes
#                        - Typical range: 100-500, max recommended: 2000
#                        - If no results found, increase this value
#   text_section_start - Start of the executable's text section
#   text_section_end   - End of the executable's text section
#
# Example (64-bit):
#   (gdb) source stack_recovery.gdb
#   (gdb) stack-recovery $sp 200 0x400000 0x7fffffffffff
#
# Example (32-bit ARM):
#   (gdb) stack-recovery $sp 200 0x8000 0x400000
#
# If no results found, increase scan_slots:
#   (gdb) stack-recovery $sp 500 <text_start> <text_end>   # Scan deeper
#   (gdb) stack-recovery $sp 1000 <text_start> <text_end>  # Even deeper
#   (gdb) stack-recovery $sp 2000 <text_start> <text_end>  # Maximum recommended
#
# Get text section bounds first:
#   (gdb) info proc mappings
#   (gdb) stack-recovery $sp 200 <text_start> <text_end>

define stack-recovery
        if $argc == 4
                # Auto-detect architecture
                if sizeof(void*) == 8
                        set $ptr_size = 8
                        printf "========================================\n"
                        printf "Stack Recovery (64-bit AArch64/x86-64)\n"
                        printf "========================================\n"
                else
                        set $ptr_size = 4
                        printf "========================================\n"
                        printf "Stack Recovery (32-bit ARM32/x86)\n"
                        printf "========================================\n"
                end

                set $i = 0
                set $scan_slots = $arg1
                set $start = $arg0
                set $text_section_start = $arg2
                set $text_section_end = $arg3
                set $found_count = 0

                printf "Start Address:  %p\n", $start
                printf "Scan Slots:     %d (total %d bytes)\n", $scan_slots, $scan_slots * $ptr_size
                printf "Text Section:   %p - %p\n\n", $text_section_start, $text_section_end

                while $i < $scan_slots
                        # Read value based on pointer size
                        if $ptr_size == 8
                                set $value = *((unsigned long*)$start)
                        else
                                set $value = *((unsigned int*)$start)
                        end

                        # Check if value is within text section range
                        if $value > $text_section_start && $value < $text_section_end
                                set $addr = $value
                                printf "[%p] ", $addr
                                info symbol $addr
                                info line *$addr
                                printf "\n"
                                set $found_count = $found_count + 1
                        end

                        set $i++
                        set $start = $start + $ptr_size
                end

                printf "========================================\n"
                printf "Found %d potential return addresses\n", $found_count

                if $found_count == 0
                        printf "\n"
                        printf "No addresses found. Try:\n"
                        printf "  - Increase scan_slots (e.g., 500, 1000, up to 2000)\n"
                        printf "  - Verify text section range with 'info proc mappings'\n"
                        printf "  - Check if $sp points to valid stack memory\n"
                end

                printf "========================================\n"
        else
                printf "Error: Invalid arguments!\n"
                printf "Usage: stack-recovery <start_address> <scan_slots> <text_section_start> <text_section_end>\n"
                printf "\n"
                printf "Parameters:\n"
                printf "  scan_slots - Number of pointer-sized slots to scan\n"
                printf "               Typical: 100-500, Max recommended: 2000\n"
                printf "\n"
                printf "Examples:\n"
                printf "  64-bit: stack-recovery $sp 200 0x400000 0x7fffffffffff\n"
                printf "  32-bit: stack-recovery $sp 200 0x8000 0x400000\n"
                printf "\n"
                printf "If no results, increase scan_slots:\n"
                printf "  stack-recovery $sp 500 <text_start> <text_end>\n"
                printf "  stack-recovery $sp 2000 <text_start> <text_end>  # Max\n"
                printf "\n"
                printf "Get text section bounds:\n"
                printf "  (gdb) info proc mappings\n"
        end
end

document stack-recovery
Stack recovery tool for completely corrupted call stacks.
Supports both 32-bit (ARM32) and 64-bit (AArch64/x86-64) architectures.

Usage: stack-recovery <start_address> <scan_slots> <text_section_start> <text_section_end>

Parameters:
    start_address      - Starting address to scan (typically $sp)
    scan_slots         - Number of pointer-sized slots to scan
                         32-bit: each slot = 4 bytes
                         64-bit: each slot = 8 bytes
                         Typical: 100-500, Max: 2000
    text_section_start - Start of executable's text section
    text_section_end   - End of executable's text section

The script will:
    1. Auto-detect architecture (32-bit or 64-bit)
    2. Scan memory for valid code pointers
    3. Display symbol and source line information

Examples:
    stack-recovery $sp 200 0x557384e000 0x557399f000  # 64-bit
    stack-recovery $sp 200 0x8000 0x400000            # 32-bit ARM

If no results found, increase scan_slots:
    stack-recovery $sp 500 <text_start> <text_end>   # Scan deeper
    stack-recovery $sp 2000 <text_start> <text_end>  # Maximum

Get text section bounds:
    (gdb) info proc mappings
end

printf "Stack recovery tool loaded\n"
printf "Usage: stack-recovery <start_address> <scan_slots> <text_start> <text_end>\n"
printf "Tip: If no results, increase scan_slots (max 2000)\n"
