---
name: coredump-analyzer
description: Linux (ARM32/AArch64) 系统的 C/C++ Core Dump 深度分析专家。当需要分析 coredump 文件时使用，使用 ssh-remote-debug 的工具脚本支持远程嵌入式设备调试。
---

# Core Dump 深度分析专家

针对 Linux ARM32/AArch64 系统的 C/C++ coredump 专家分析。分析 GDB 调试信息、二进制/库文件、源代码和日志，识别根本原因并提供代码级修复方案。**支持远程嵌入式设备调试**（使用 ssh-remote-debug 的远程执行和文件传输工具）。

## ⚠️ 必须遵循的分析流程

**重要**：Coredump 分析不是线性流程，而是**多维度并行证据采集 + 交叉验证**的过程。

### 📊 多维证据采集框架（核心方法论）

**分析分为 3 个阶段**：
1. **阶段 1：环境验证** - 确认文件存在、工具可用
2. **阶段 2：多维证据采集（并行）** - 同时从 5 个维度收集所有证据
3. **阶段 3：交叉验证与根因定位** - 让证据相互印证，找到共同指向

### 📋 阶段 1：环境验证（快速完成）

**在开始分析前，必须先创建 Todo 列表：**

```python
TodoWrite([
    # 阶段 1：环境验证
    {"content": "【阶段1.1】验证文件存在和工具可用", "activeForm": "验证环境", "status": "in_progress"},
    {"content": "【阶段1.2】运行快速分析脚本获取基础报告", "activeForm": "生成基础报告", "status": "pending"},
    {"content": "【阶段1.3】读取完整 reference 文档并识别症状", "activeForm": "读取 reference", "status": "pending"},

    # 阶段 2：多维证据采集（必须全部完成）
    {"content": "【维度1】内存指纹：崩溃点前后内存分析", "activeForm": "采集内存指纹", "status": "pending"},
    {"content": "【维度2】完整调用链：所有线程bt+崩溃帧详情", "activeForm": "采集调用链", "status": "pending"},
    {"content": "【维度3】数据结构：损坏对象内部状态检查", "activeForm": "检查数据结构", "status": "pending"},
    {"content": "【维度4】寄存器+映射：PC/SP/LR/FP+内存映射表", "activeForm": "采集寄存器信息", "status": "pending"},
    {"content": "【维度5】源码逻辑：崩溃函数+调用者代码", "activeForm": "阅读相关源码", "status": "pending"},

    {"content": "🔍 反思检查：验证所有假设并计算关键比例", "activeForm": "执行反思检查", "status": "pending"},

    # 阶段 2-3 门禁检查
    {"content": "🚪 门禁检查：验证阶段2的5个维度全部完成", "activeForm": "验证阶段2完成", "status": "pending"},

    # 阶段 3：交叉验证与根因定位
    {"content": "【阶段3】交叉验证：证据是否相互印证", "activeForm": "交叉验证证据", "status": "pending"},
    {"content": "【阶段3】根因定位：找到共同指向的操作", "activeForm": "定位根本原因", "status": "pending"},
    {"content": "【阶段3】代码级修复：提供具体修改方案", "activeForm": "提供修复建议", "status": "pending"}
])
```

⚠️ **重要**：在分析开始时就创建包含所有阶段的完整 Todo 列表，这样可以清楚看到整个流程，避免跳步。

### 📋 阶段 2：多维证据采集（并行执行，不分先后）

⚠️ **关键规则**：这 5 个维度的证据**必须全部采集完成**才能进入阶段 3，不能跳过任何维度。

**Todo 列表已在阶段 1 创建。开始阶段 2 时：**
- ✅ **可以并行采集多个维度**：不必等一个维度完成才开始下一个
- ✅ **灵活调整顺序**：根据实际情况选择最合适的采集顺序
- ✅ **同时标记多个 in_progress**：可以同时有多个维度处于进行中状态
- ⚠️ **必须全部完成**：所有 5 个维度最终都必须标记为 completed

**自检问题**（每个维度完成后必须回答）：
- 维度1：是否检查了至少 1024 字节？是否识别出异常重复模式/ASCII/魔术数字？
- 维度2：是否获取了所有线程的 bt？是否检查了崩溃帧的局部变量？
- 维度3：是否检查了损坏对象的关键字段？是否理解了其数据结构？
- 维度4：是否验证了所有寄存器值的合法性？是否确认了内存映射关系？
- 维度5：是否阅读了崩溃函数的完整逻辑？是否追溯了调用者？

---

### 🔍 反思检查：进入门禁前的强制自查

⛔ **在标记"🚪 门禁检查"为 in_progress 之前，必须先完成以下反思：**

#### 1. 假设验证清单（必须逐项回答）

**列出分析中的所有假设**，并检查：

- [ ] 我做了哪些假设？（明确列出至少 3 个）
- [ ] 每个假设是基于"数据"还是"经验"？
- [ ] 低成本（< 30 秒）的假设是否都已验证？
- [ ] 是否有假设与已有数据矛盾？

#### 2. 数字合理性检查（必须计算）

**强制计算以下比例**：

- [ ] 可疑对象大小 / 总可用空间 = ?
   - 如果 < 1%，它能独立导致崩溃吗？
   - 示例：4KB buffer / 8MB stack = 0.05%
   - 有没有其他可能？例如递归？循环？

- [ ] 所有所谓的 "既知事实" ，是否经过验证？

#### 3. 全局扫描检查（必须回答）

- [ ] 是否扫描了所有 5 个维度的数据？
- [ ] 是否按量级排序了所有异常？
- [ ] 当前关注的对象是"最大的异常"吗？
- [ ] 是否有其他维度的证据与当前结论矛盾？

---

  ✅ **只有当上述 3 个检查清单全部完成后，才能将"🔍 反思检查"标记为 completed，并开始标记"🚪 门禁检查"为 in_progress**

--- 

### 🚪 门禁检查：进入阶段 3 前的强制验证

**在标记"🚪 门禁检查"这个 todo 为 in_progress 之前，必须确认：**

**1. 检查 Todo 列表状态**：
- [ ] 【维度1】内存指纹 → status: completed
- [ ] 【维度2】完整调用链 → status: completed
- [ ] 【维度3】数据结构 → status: completed
- [ ] 【维度4】寄存器+映射 → status: completed
- [ ] 【维度5】源码逻辑 → status: completed

**2. 自检所有维度的自检问题**：
- [ ] 维度1的3个问题都已回答
- [ ] 维度2的4个问题都已回答
  - [ ] 如果bt损坏，stack-recovery工具的使用证明：
        - 记录了text段范围
        - 执行了stack-recovery命令
        - 记录了扫描结果（找到X个返回地址 或 无结果）
- [ ] 维度3的3个问题都已回答
- [ ] 维度4的3个问题都已回答
- [ ] 维度5的4个问题都已回答

**3. 维度5 代码搜索证明（强制要求，违反则禁止进入阶段3）**：

必须提供以下证据：

**搜索尝试记录**（至少3种不同模式）：
- [ ] 搜索1: `<实际执行的命令>` → 找到 X 个结果
- [ ] 搜索2: `<实际执行的命令>` → 找到 Y 个结果
- [ ] 搜索3: `<实际执行的命令>` → 找到 Z 个结果

**最少必须覆盖以下类型中的3种**：
1. 内存操作类：`memset|memcpy|memmove|strcpy|sprintf` + 特征值
2. 循环赋值类：`= <特征值>` 结合 `for|while` 上下文
3. 数组赋值类：`\[.*\].*= <特征值>` (任意维度、任意下标名)
4. 结构体赋值类：`\.[a-zA-Z_]+.*= <特征值>`
5. 初始化列表类：`{.*<特征值>.*}` (数组/结构体初始化)

**合格示例**（假设内存特征值为 -1 / 0xffffffff）：
```bash
✅ 已尝试3种不同类型的搜索：
1. grep -rn "memset.*-1\|memset.*0xff" src/     → 12个结果，逐个检查后排除
2. grep -rn "= -1" src/ | grep -B3 "for\|while" → 31个结果，发现多处可疑循环
3. grep -rn "\[.*\].*= -1" src/                 → 8个结果，其中buffer_mgr.cpp中有数组越界
```

**不合格示例**（禁止通过门禁）：
```bash
❌ 只尝试了同一类型的搜索：
1. grep -rn "memset.*-1" src/          → 12个结果
2. grep -rn "memset.*0xff" src/        → 8个结果
3. grep -rn "memset.*0xffffffff" src/  → 5个结果
→ 都属于"内存操作类"，必须尝试其他类型！
```

⛔ **如果任何一个维度未完成或自检问题未回答，禁止进入阶段 3**

⛔ **如果维度5只尝试了1-2种模式，或所有模式都属于同一类型，必须返回阶段2继续搜索**

✅ **当所有检查通过后**：
1. 将"🚪 门禁检查"标记为 completed
2. 开始阶段 3 的第一个任务："【阶段3】交叉验证"

---

### 📋 阶段 3：交叉验证与根因定位

⛔ **进入阶段 3 前的强制检查**：
1. 在 Todo 列表中确认"🚪 门禁检查"已标记为 completed
2. 如果未完成，必须先返回阶段 2 完成所有维度

**Todo 列表中的阶段 3 任务**（已在阶段 1 创建）：
- 【阶段3】交叉验证：证据是否相互印证
- 【阶段3】根因定位：找到共同指向的操作
- 【阶段3】代码级修复：提供具体修改方案

**交叉验证检查表**（必须全部回答"是"）：
- [ ] 内存模式 + 源码逻辑 → 是否指向同一操作？
- [ ] 调用栈 + 内存映射 → 损坏位置是否合理？
- [ ] 数据结构状态 + 内存指纹 → 损坏方式是否符合预期？
- [ ] 寄存器值 + 代码逻辑 → 执行路径是否可能？
- [ ] 所有证据是否收敛到同一个"凶手"操作？

---

## 核心原则

1. **证据优先**：先采集所有维度的证据，再做结论。禁止"先有理论，再找证据"
2. **受害者 vs 凶手**：崩溃点往往只是受害者；真正的凶手可能在几KB外的内存操作中
3. **尊重数据**：GDB 内存值是最高真理。代码有锁不代表安全，代码看起来正常不代表没有 bug
4. **全局视角**：不能只看崩溃点附近 32 字节，必须检查周围 1024 字节以上
5. **交叉验证**：任何结论必须有至少 3 个不同维度的证据相互印证

## 核心方法论：假设-验证-质疑循环（HVQ Loop）

### 规则
在分析的**任何阶段**，当你形成一个判断时：

1. **识别**：这是假设还是事实？
   - 如果是**从数据直接读取的** → 事实
   - 如果是**你推理出来的** → 假设

2. **标记**：显式标记所有假设
   假设 H1: [陈述]
   基于: [什么数据/观察]
   未验证的前提: [列出]

3. **验证成本评估**：
- 如果验证成本 < 1 分钟 → **必须立即验证**
- 如果验证成本 > 5 分钟 → 标记为"待验证假设"，继续分析

4. **反向质疑**：
每个假设都要问：
- "如果这个假设错了，会导致什么？"
- "有没有数据与这个假设矛盾？"
- "这个假设来自哪里？（经验/文档/猜测）"

### 强制检查点

在以下时刻**必须**执行 HVQ 循环：
- 得出任何结论前
- 准备写修复方案前
- 发现"关键证据"时（质疑：这真的是关键吗？）

## ⛔ 绝对禁止的行为（常见错误陷阱）

### 陷阱 1：看到锁就放松警惕
❌ **错误思维**："代码有 `std::lock_guard`，不可能是并发问题"
✅ **正确思维**："锁只保护临界区，不保护数组边界、指针合法性、生命周期"

### 陷阱 2：先想理论，再找证据
❌ **错误流程**：看到崩溃 → 根据经验猜测原因 → 找支持理论的证据
✅ **正确流程**：看到崩溃 → 多维度采集所有证据 → 让证据告诉你原因

### 陷阱 3：只看局部内存
❌ **错误做法**：只看崩溃点附近 32 字节就下结论
✅ **正确做法**：至少检查前后 1024 字节，寻找重复模式和间隔规律

### 陷阱 4：忽略"非崩溃点"的代码
❌ **错误思维**："崩溃在 A 函数，问题就在 A 函数里"
✅ **正确思维**："崩溃在 A，凶手可能在 B/C/D 函数中，禁止过早下结论"

### 陷阱 5：相信代码，不相信内存
❌ **错误思维**："代码逻辑没问题，可能是编译器/内核/库的 bug"
✅ **正确思维**："内存数据不会撒谎，如果矛盾，一定是代码有问题"

### 陷阱 6：单一假设 + 线性深挖
❌ **错误思维**："调用栈在模块 A，先深入搜索 A 的所有代码，找不到再看其他"
✅ **正确思维**："同时建立多个假设，根据证据强度分配搜索精力，动态调整方向"

### 陷阱 7：相信经验，不验证假设

❌ **错误思维**："嵌入式设备线程栈肯定很小"
✅ **正确思维**："用 GDB 计算实际栈使用量"

**核心原则**：
- 调用栈显示的是**受害者**，不是**凶手**
- 不要让调用栈限制你的搜索范围
- 维持多个并行假设，避免过早排除正确答案

**操作要点**：
1. 阶段 2 结束时，从 5 个维度的证据中提取**多个**可能的凶手假设
2. 评估每个假设的证据支持度（有多少维度的证据指向它）
3. 优先验证证据支持度高的假设，但不要完全放弃其他假设
4. 搜索一个方向 5-10 分钟无果 → 切换到另一个假设，避免陷入局部深挖
5. 发现新证据时，重新评估所有假设的支持度

**关键认知**：
- 凶手的位置可能与调用栈中的任何函数**完全无关**
- 凶手可能在受害者之前几秒、几百行、几个模块之外
- 不要因为"已经在这个方向搜了很久"而继续挖下去（沉没成本谬误）

## 分析工作流（3 阶段法）

---

### 阶段 1：环境验证与基础报告

**目标**：确认文件可用 + 生成初始诊断报告

#### 1.1 验证环境（本地或远程）

<details>
<summary>远程分析（使用 ssh-remote-debug 工具）</summary>

```bash
# 注意：如果 SSH 端口不是 22，需要添加 -P <port> 参数
# 默认凭据：-u root -p rockchip（可以省略）

# 1. 验证文件存在和大小
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> "ls -lh /path/to/binary /path/to/coredump" -P <port>

# 2. 确认 GDB 可用（必须）
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> "which gdb && gdb --version | head -1" -P <port>

# 3. 可选：查找设备上的 coredump（如果路径未知）
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> "find /var/coredump /tmp /userdata -name 'core*' -type f 2>/dev/null" -P <port>

# 4. 可选：检查 coredump 配置
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> "cat /proc/sys/kernel/core_pattern" -P <port>
```

</details>

#### 1.2 生成快速分析报告（必须）

⚠️ **此报告是后续所有分析的基础！**

<details>
<summary>远程分析</summary>

```bash
# 注意：如果 SSH 端口不是 22，在 scp_transfer.py 和 ssh_executor.py 中都需要添加 -P <port>

# 1. 先上传脚本到远程设备
python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
  .claude/skills/coredump-analyzer/scripts/quick_coredump_analysis.sh /tmp/quick_coredump_analysis.sh -H <host> -P <port>

# 2. 在远程设备上运行脚本
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> \
  "chmod +x /tmp/quick_coredump_analysis.sh && /tmp/quick_coredump_analysis.sh /path/to/binary /path/to/coredump" -P <port>
```
</details>

**此脚本会自动执行**：
- 基本 GDB 诊断（bt, info registers, thread apply all bt）
- 内存映射分析
- 寄存器状态检查
- 所有线程堆栈
- 崩溃线程每个帧栈的栈消耗

#### 1.3 读取 Reference 文档并识别症状（⛔ 新增强制步骤）
<details>
<summary>参考文档读取（使用 Read）</summary>
  **⛔ 在进入阶段 2 前，必须完整读取 reference 文档**：

  ```bash
  Read(file_path=".claude/skills/coredump-analyzer/references/analysis-methodology.md")
  ```

   **初步识别崩溃模式**（为阶段 2 做准备）：
   - **栈损坏**：`bt` 显示 `??` 或断裂的栈帧 → 查阅 [栈回溯破坏类](references/analysis-methodology.md#栈回溯破坏类)
     - **强制行动**：如识别为栈损坏，在维度2中**必须**使用stack-recovery工具恢复
   - **特定位置**：崩溃在 malloc/free、函数入口/出口 → 查阅 [内存相关崩溃类](references/analysis-methodology.md#内存相关崩溃类)
   - **特殊信号**：STL 内部、虚函数 → 查阅 [特殊信号与指令类](references/analysis-methodology.md#特殊信号与指令类)
</details>

**更新 TodoWrite**：完成阶段 1 的两个任务

---

### 阶段 2：多维证据采集（核心阶段）

⚠️ **关键规则**：
1. 这 5 个维度的证据**必须全部采集**，不能跳过任何一个
2. 可以并行采集，不分先后顺序
3. 采集完所有证据后才能进入阶段 3

#### 维度 1：内存指纹分析

**目标**：识别规律性模式

⚠️ **必须使用 memory_fingerprint.gdb 工具**


```bash
# 注意：如果 SSH 端口不是 22，需要添加 -P <port> 参数

# 1. 先上传 GDB 脚本到远程设备
python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
  .claude/skills/coredump-analyzer/scripts/memory_fingerprint.gdb /tmp/memory_fingerprint.gdb -H <host> -P <port>
python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
  .claude/skills/coredump-analyzer/scripts/stack_recovery.gdb /tmp/stack_recovery.gdb -H <host> -P <port>
python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
  .claude/skills/coredump-analyzer/scripts/vptr_checker.gdb /tmp/vptr_checker.gdb -H <host> -P <port>

# 2. 在远程设备上启动 GDB 并使用工具
python .claude/skills/ssh-remote-debug/scripts/ssh_executor.py <host> \
  "gdb /path/to/binary /path/to/coredump -ex 'source /tmp/memory_fingerprint.gdb' -ex 'source /tmp/stack_recovery.gdb' -ex 'source /tmp/vptr_checker.gdb' -ex 'memory-fingerprint \$sp 256' -ex 'quit'" -P <port>
```

**工具选择指南**：
- **栈损坏** → 使用 `stack-recovery` 恢复调用栈，配合 `memory-fingerprint` 分析内存
- **堆损坏/malloc崩溃** → 使用 `memory-fingerprint` 检查 chunk header
- **虚函数崩溃** → 使用 `check-vptr` 验证虚表
- **STL容器崩溃** → 使用 `memory-fingerprint` 检查节点内存

**自检问题**：
- 是否检查了至少 1024 字节的内存？
- 是否识别出异常的重复模式/ASCII痕迹或魔术数字？
- 是否初步判定内存损坏类型？

**更新 TodoWrite**：标记"【维度1】内存指纹"为 completed

---

#### 维度 2：完整调用链分析（必须：所有线程）

**目标**：获取所有线程的完整调用栈和崩溃帧的详细信息

⚠️ **不能只看崩溃线程的 bt，必须检查所有线程**

- 收集通用信息
```bash
# 在 GDB 中执行（通过 ssh_executor 远程执行）
(gdb) info threads                    # 查看所有线程
(gdb) thread apply all bt full         # 所有线程的完整堆栈
(gdb) frame 0                         # 切换到崩溃帧
(gdb) info locals                     # 查看局部变量
(gdb) info args                       # 查看函数参数
```

- 计算相邻栈帧之间的距离
```
  Frame #0 SP: 0xXXXX
  Frame #1 SP: 0xYYYY
  距离 = |0xYYYY - 0xXXXX| = ??? bytes
```

- 栈损坏强制处理流程：
  如果bt显示**全部栈帧**都是`??`时，必须执行栈恢复：
  - 栈恢复步骤（强制）：
  1. 获取text段范围：
  (gdb) info proc mappings
  # 查找包含可执行代码的映射区域，记录起止地址

  2. 执行栈恢复（扫描至少200 slots）：
  (gdb) source /tmp/stack_recovery.gdb
  (gdb) stack-recovery $sp 200 <text_start> <text_end>

  # 示例 (64-bit): stack-recovery $sp 200 0x557384e000 0x557399f000
  # 示例 (32-bit): stack-recovery $sp 200 0x8000 0x400000

  # 如果未找到结果，增大扫描范围:
  (gdb) stack-recovery $sp 500 <text_start> <text_end>
  # 最大推荐: stack-recovery $sp 2000 <text_start> <text_end>

  3. 分析恢复结果：
  - 记录所有找到的返回地址
  - 结合LR寄存器的值交叉验证
  - 手动构建调用链

**自检问题**：
- 是否获取了所有线程的 bt？
- 如果bt显示`??`或"corrupt stack"，是否使用了stack-recovery工具尝试恢复？
- 如果使用了stack-recovery，扫描范围是否足够（至少200 slots，text段范围正确）？
- 是否检查了崩溃帧的局部变量？
- 是否确认了每个栈帧的有效性？
- 是否计算了每层栈帧的消耗？

**更新 TodoWrite**：只有自检问题全部回答为是时，才能标记"【维度2】完整调用链"为 completed，否则重复维度2

---

#### 维度 3：数据结构状态检查（必须：损坏对象）

**目标**：检查崩溃时涉及的对象/数据结构的内部状态

##### STL 容器检查

```bash
# 检查 STL 容器状态
(gdb) print container.size()           # 检查 size 是否异常
(gdb) print container._M_impl          # 检查内部实现
(gdb) print *container._M_impl._M_node # 检查节点指针
```

##### 对象成员检查

```bash
# 检查对象成员变量
(gdb) print *object_ptr                # 打印整个对象
(gdb) print object_ptr->member_var     # 检查特定成员
(gdb) x/32gx object_ptr                # 以十六进制查看对象内存
```

**自检问题**：
- 是否检查了损坏对象的关键字段？
- 是否理解了其数据结构布局？
- 是否发现字段值异常（如 size 为天文数字）？

**更新 TodoWrite**：标记"【维度3】数据结构"为 completed

---

#### 维度 4：寄存器和内存映射（必须：验证合法性）

**目标**：验证所有关键寄存器的值是否合法，确认内存映射关系

##### 寄存器检查

```bash
# 检查所有寄存器（已在快速分析报告中）
(gdb) info registers                   # 所有寄存器
(gdb) info registers pc sp lr fp       # 关键寄存器（ARM/AArch64）

# 验证寄存器指向的内存
(gdb) x/i $pc                          # PC 指向的指令
(gdb) x/8gx $sp                        # SP 指向的栈内容
(gdb) x/i $lr-4                        # LR 之前的调用指令
```

##### 内存映射检查

```bash
# 查看内存映射表（已在快速分析报告中）
(gdb) info proc mappings               # 所有内存区域

# 验证地址是否在合法区域
# 检查崩溃地址是否在映射表中
```

**自检问题**：
- 是否验证了所有寄存器值的合法性？
- 是否确认了崩溃地址在内存映射中的位置？
- PC/SP/LR 是否指向合法内存区域？

**更新 TodoWrite**：标记"【维度4】寄存器+映射"为 completed

---

#### 维度 5：源码逻辑分析（必须：崩溃函数+调用者）

**目标**：基于前 4 个维度的证据，建立多个假设并验证

⚠️ **关键原则**：不要让调用栈限制搜索范围

##### 第 1 步：综合前 4 维证据，建立假设列表

在开始搜索代码前，**必须先回答**：

1. **内存指纹告诉我什么**？
   - 重复模式的间隔 → 可能是哪种数据结构的大小？
   - 损坏值的特征 → 可能是什么操作（初始化、清零、赋值）？
   - 损坏范围的大小 → 可能越界了多少元素？

2. **调用链告诉我什么（警惕误导）**？
   - 崩溃在哪个模块/对象？（这是受害者）
   - 哪些对象在崩溃前被构造/初始化？（可能的凶手候选）
   - 是否有多线程参与？（并发问题可能性）

3. **数据结构状态告诉我什么**？
   - 损坏的是什么类型的对象？
   - 是单个字段被破坏，还是整块内存被覆盖？
   - 损坏值是否有意义（如 0/-1/0xff）？

4. **寄存器和映射告诉我什么**？
   - 崩溃地址是栈、堆、还是全局数据区？
   - 如果是堆，损坏发生在哪个阶段（分配时/使用中）？

**基于以上分析，列出至少 2-3 个假设**，每个假设包含：
- 假设的凶手类型（数组越界/指针错误/多线程竞争/...）
- 支持该假设的证据数量（1-5 个维度）
- 初步搜索策略（搜索什么模式、在哪些目录）

##### 第 2 步：根据假设优先级，设计搜索策略

**高优先级假设**（3+ 维度证据支持）：
- 优先搜索，可以投入更多时间
- 从最可能的模块开始，但不限制在该模块

**中优先级假设**（1-2 维度证据支持）：
- 快速扫描，5 分钟内无果则切换
- 考虑并行验证（同时搜索多个方向）

⚠️ **关键要求**：**禁止只使用单一搜索模式**

**代码搜索必须覆盖至少 3 种不同类型**（从以下 5 种中选择）：
1. 内存操作类：`memset|memcpy|memmove|strcpy|sprintf` + 特征值
2. 循环赋值类：`= <特征值>` 结合上下文检查是否在循环中
3. 数组赋值类：`\[.*\].*= <特征值>` (任意维度、任意下标名)
4. 结构体赋值类：`\.[a-zA-Z_]+.*= <特征值>`
5. 初始化列表类：`{.*<特征值>.*}` (数组/结构体初始化)

**搜索示例**（假设内存特征值为 `-1` / `0xffffffff`）：

```
# 类型1：内存操作类
Grep(pattern="memset.*-1|memset.*0xff", path="/path/to/source", output_mode="files_with_matches")

# 类型2：循环赋值类（如果内存有规律性间隔，优先级高）
# 搜索数组索引赋值，显示前5行检查是否有 for/while 循环
Grep(pattern="\\[[a-zA-Z_][a-zA-Z0-9_]*\\].*=.*-1", path="/path/to/source", output_mode="content", -B=5)

# 类型3：二维数组赋值类（如果内存有规律间隔，优先级高）
Grep(pattern="\\[.*\\]\\[.*\\].*=.*-1", path="/path/to/source", output_mode="content", -B=5)

# 类型4：结构体数组字段赋值类（如果内存有规律间隔，优先级高）
Grep(pattern="\\[.*\\]\\.[a-zA-Z_][a-zA-Z0-9_]*.*=.*-1", path="/path/to/source", output_mode="content", -B=5)

# 类型5：初始化列表类
Grep(pattern="\\{.*-1.*\\}", path="/path/to/source", output_mode="content")
```

**重要**：
- 每种搜索的结果数量都要记录（用于门禁检查）
- 至少尝试 3 种不同类型，不能都属于同一类型
- 根据内存指纹特征调整搜索优先级

##### 第 3 步：源码阅读（多假设并行）

```
使用 Read 工具阅读：
1. 崩溃函数的完整实现（理解受害者）
2. 调用栈中所有函数的完整实现（可能有线索，但不是唯一方向）
3. **结合上下文**，搜索结果中的可疑代码（根据假设优先级）
4. 相关数据结构的定义，并结合上下文分析（理解大小和布局）
```

**重点关注**：
- 数组/缓冲区的边界检查
- 循环变量和数组维度的对应关系
- 初始化代码（构造函数、init 函数、静态初始化）
- 指针的生命周期管理
- 多线程访问的同步机制

⚠️ **对于每个可疑函数/代码行，必须回答以下问题**：

  **上下文检查清单**：
  - [ ] 此代码在什么**控制流**中？（裸代码/if分支/循环/递归）
  - [ ] 如果在**循环**中：
    - 循环类型：for / while / do-while / goto 循环
    - 退出条件：何时退出？最大迭代次数是多少？
    - **累积计算**：`单次操作量 × 迭代次数 = ?`
  - [ ] 如果在**递归**中：
    - 最大递归深度：理论值/实际观察值
    - **累积计算**：`单帧大小 × 最大深度 = ?`
  - [ ] 资源的**生命周期**：
    - 何时分配？（函数入口/循环内/条件分支）
    - 何时释放？（函数出口/循环内/从不释放）
    - 是否有"分配在循环内，释放在函数出口"的**累积模式**？

##### 第 4 步：动态调整策略

- **找到强证据** → 深入该方向，提高该假设优先级
- **5-10 分钟无进展** → 切换到其他假设，避免局部深挖
- **发现新证据矛盾当前假设** → 放弃该方向，建立新假设
- **多个假设都指向同一位置** → 这很可能是凶手

**自检问题**：
- 是否基于所有 5 维证据建立了假设？（不能只依赖调用栈）
- 是否至少尝试了 2-3 个不同方向？（避免单一假设陷阱）
- 搜索范围是否被调用栈限制了？（凶手可能在完全无关的模块）
- 是否在某个方向上深挖超过 10 分钟仍无果？（应切换方向）

**更新 TodoWrite**：标记"【维度5】源码逻辑"为 completed

---

### ✅ 阶段 2 完成检查点

**当 5 个维度全部标记为 completed 后，必须执行门禁检查**：
1. 将 Todo 列表中的"🚪 门禁检查"标记为 in_progress
2. 按照门禁检查清单逐项验证
3. 通过后将"🚪 门禁检查"标记为 completed
4. 然后才能开始阶段 3

⛔ **禁止跳过门禁检查直接进入阶段 3**

---

### 阶段 3：交叉验证与根因定位

⛔ **进入阶段 3 前的强制检查**：
1. **先完成门禁检查**：将 Todo 列表中的"🚪 门禁检查"标记为 in_progress
2. **确认 5 个维度全部 completed**：检查【维度1】到【维度5】的状态
3. **确认所有自检问题已回答**：每个维度的自检问题都已在分析过程中回答
4. **通过门禁后**：将"🚪 门禁检查"标记为 completed，然后开始阶段 3

**交叉验证检查表**（必须全部回答"是"）：
- [ ] 内存模式 + 源码逻辑 → 是否指向同一操作？
- [ ] 调用栈 + 内存映射 → 损坏位置是否合理？
- [ ] 数据结构状态 + 内存指纹 → 损坏方式是否符合预期？
- [ ] 寄存器值 + 代码逻辑 → 执行路径是否可能？
- [ ] 所有证据是否收敛到同一个"凶手"操作？

#### 根因分析方法

1. **建立假设**：基于 5 个维度的证据，建立初步假设
2. **寻找共同指向**：
   - 哪个操作能同时解释内存模式、调用栈、数据结构状态？
   - 哪段代码能导致寄存器和内存映射中观察到的现象？
3. **验证假设**：
   - 将内存指纹匹配到源代码中的具体操作
   - 从崩溃点向后追踪数据流
   - 确认"凶手"操作（受害者 vs 凶手原则）
4. **代码级定位**：
   - 精确到文件名、函数名、行号
   - 识别导致问题的特定变量或操作
   - 理解为什么这个操作会导致崩溃

**更新 TodoWrite**：标记"交叉验证"和"根因定位"为 completed

---

#### 提供修复方案（最终输出）

⚠️ **必须提供代码级修复建议，不能只给笼统结论**

**必须包含**：
- ✅ **精确的文件路径和行号**（如：`/path/to/project/src/module/file.cpp:123`）
- ✅ **导致问题的特定变量或操作**（如："变量 ptr 指针被非法值覆盖"）
- ✅ **具体的代码修改建议**（提供修改前后的代码对比）
- ✅ **为什么此修复能解决根本原因**（解释修复逻辑）
- ✅ **建议的验证方法**（如：AddressSanitizer、单元测试）

**禁止的笼统建议**：
- ❌ "可能是内存越界"
- ❌ "建议添加边界检查"
- ❌ "需要修复内存管理"

**更新 TodoWrite**：标记"提供修复建议"为 completed

**向用户汇报**：所有步骤已完成，提供完整的分析报告和修复方案

---

## 快速参考：常见崩溃模式

| 症状 | 可能原因 | 首要行动 |
|------|---------|---------|
| `bt` 全为 `??` | 野指针跳转 / SP 损坏 | 检查 `$lr`，扫描栈查找返回地址 |
| `#0` 正常，其余 `??` | 帧 #0 中的栈溢出 | 检查 `$sp` 到 `$fp` 间内存，寻找缓冲区溢出 |
| 崩溃在 `malloc/free` | Double-free / 堆损坏 | 检查 chunk header，寻找 ASCII 痕迹 |
| 函数入口崩溃 | NULL/野 `this` 指针或栈溢出 | 检查 `si_addr` 和 `$sp` 有效性 |
| STL 内部崩溃 | 迭代器失效 / 竞争条件 | 检查是否多线程，验证容器状态 |
| 虚函数调用崩溃 | vptr 被破坏 | 检查对象的前 8 字节 |

## 嵌入式设备特殊注意事项

### 内存受限环境

1. **有限的调试工具**：
   - 某些嵌入式设备可能没有完整的 GDB
   - 可能需要 gdbserver + 远程调试
   - 本 skill 的所有脚本均为 bash + 纯 GDB 命令，可直接在设备上运行

2. **交叉编译环境**：
   - 确保 GDB 版本与目标架构匹配
   - ARM32 vs AArch64 的差异
   - Thumb vs ARM 指令集模式

### 常见嵌入式问题

- **栈大小限制**：嵌入式系统通常有较小的栈空间
- **未对齐访问**：ARM 架构对内存对齐要求严格
- **MMU 配置**：某些嵌入式系统有特殊的内存映射

## 资源文件

### references/
- **analysis-methodology.md**：所有崩溃模式的完整方法论和详细调查步骤

### scripts/ （所有脚本可在嵌入式设备上运行，无需 Python）

**GDB 分析命令（纯 GDB 命令，无需 Python）：**
- **memory_fingerprint.gdb**：分析内存模式（ASCII 痕迹、重复字节、魔术数字）
- **stack_recovery.gdb**：当栈完全破坏时恢复调用栈（支持 32/64 位架构）
- **vptr_checker.gdb**：验证 C++ 对象虚表指针
- **gdb_batch_commands.txt**：快速证据收集的批量 GDB 命令

**Bash 分析工具（可在嵌入式设备上直接运行）：**
- **quick_coredump_analysis.sh**：一键生成完整 coredump 分析报告

## 使用示例

### 示例 1：远程嵌入式设备

**用户请求**："我的嵌入式设备上的应用崩溃了，coredump 在 /var/coredump/core.1234"

**预期工作流**：
1. 连接到远程设备（使用 ssh-remote-debug 工具）
2. 将分析脚本上传到设备（使用 scp_transfer.py）：
   ```bash
   # 上传分析脚本
   python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
     .claude/skills/coredump-analyzer/scripts/quick_coredump_analysis.sh /tmp/quick_coredump_analysis.sh -H device
   # 上传 GDB 脚本
   python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
     .claude/skills/coredump-analyzer/scripts/memory_fingerprint.gdb /tmp/memory_fingerprint.gdb -H device
   python .claude/skills/ssh-remote-debug/scripts/scp_transfer.py upload \
     .claude/skills/coredump-analyzer/scripts/stack_recovery.gdb /tmp/stack_recovery.gdb -H device
   ```
3. 在远程设备上运行快速分析：
   ```bash
   ssh root@device
   cd /tmp
   ./quick_coredump_analysis.sh /usr/bin/myapp /var/coredump/core.1234 > /tmp/crash_report.txt
   ```
4. 下载报告进行详细分析，或直接在设备上用 GDB 交互分析：
   ```bash
   gdb /usr/bin/myapp /var/coredump/core.1234
   (gdb) source /tmp/memory_fingerprint.gdb
   (gdb) source /tmp/stack_recovery.gdb
   ```
5. 执行分析工作流识别根本原因
6. 考虑嵌入式特定因素（栈大小、对齐、架构差异）
7. 提供针对嵌入式环境的修复建议

### 示例 2：栈损坏（无法 bt）

**用户请求**："GDB bt 只显示 ??，无法看到调用栈"

**预期工作流**：
1. 识别为完全栈损坏模式
2. 获取 text section 的地址范围：
   ```bash
   (gdb) info proc mappings   # 查找 <binary> 对应的代码段起止地址
   ```
3. 加载并使用栈恢复工具：
   ```bash
   (gdb) source scripts/stack_recovery.gdb
   (gdb) stack-recovery $sp 200 <text_start> <text_end>
   # 示例 (64-bit): stack-recovery $sp 200 0x557384e000 0x557399f000
   # 示例 (32-bit): stack-recovery $sp 200 0x8000 0x400000
   # 如果未找到结果，增大扫描范围: stack-recovery $sp 500 <text_start> <text_end>
   # 最大推荐: stack-recovery $sp 2000 <text_start> <text_end>
   ```
4. 分析输出的函数调用链，识别崩溃前的执行路径
5. 使用 memory-fingerprint 检查栈内存是否有规律性损坏
6. 定位导致栈指针损坏的操作
7. 提供具体修复方案

## GDB 脚本使用指南

### 快速开始（推荐）

**一键分析报告**（无需交互）：

```bash
# 在设备上直接生成完整报告
./scripts/quick_coredump_analysis.sh /usr/bin/myapp /var/coredump/core.1234 report.txt

# 查看报告
less report.txt
```

### 交互式 GDB 分析

**在 GDB 中加载分析工具**（所有脚本均为纯 GDB 命令，无需 Python）：

```bash
# 启动 GDB
gdb /usr/bin/myapp /var/coredump/core.1234

# 加载分析工具
(gdb) source scripts/memory_fingerprint.gdb
(gdb) source scripts/stack_recovery.gdb
(gdb) source scripts/vptr_checker.gdb

# 使用自定义命令进行分析
(gdb) memory-fingerprint $sp 256        # 分析栈内存指纹
(gdb) stack-recovery $sp 200 <text_start> <text_end>  # 恢复被破坏的调用栈
(gdb) check-vptr $x0                    # 检查 C++ 虚表指针

# 或加载批量命令一次性执行所有基本检查
(gdb) source scripts/gdb_batch_commands.txt
```

**GDB 命令说明**：

- `memory-fingerprint <address> [size]` - 分析内存模式
  - 示例：`memory-fingerprint $sp 1024`
  - 示例：`memory-fingerprint 0x7fffffffd000`

- `stack-recovery <start_addr> <scan_slots> <text_start> <text_end>` - 恢复被破坏的调用栈
  - 示例 (64-bit)：`stack-recovery $sp 200 0x557384e000 0x557399f000`
  - 示例 (32-bit)：`stack-recovery $sp 200 0x8000 0x400000`
  - **scan_slots**：扫描的指针大小槽位数（32-bit: 4字节/槽，64-bit: 8字节/槽）
    - 典型范围：100-500
    - 最大推荐：2000
    - 未找到结果时可增大：`stack-recovery $sp 500 ...` 或 `stack-recovery $sp 2000 ...`
  - **注意**：需先通过 `info proc mappings` 获取 text section 范围
  - **自动检测架构**：32-bit ARM/x86 或 64-bit AArch64/x86-64

- `check-vptr <object_address>` - 检查虚表指针
  - 示例：`check-vptr $x0` （AArch64 的 this）
  - 示例：`check-vptr $rdi` （x86-64 的 this）


## 依赖的工具

- **ssh-remote-debug 工具脚本**：
  - `ssh_executor.py` - 在远程设备上执行命令
  - `scp_transfer.py` - 在本地和远程设备间传输文件
  - 默认凭据：root/rockchip
- 可扩展支持其他远程访问或文件传输工具
